package com.BMI.Calculator;


import java.text.DecimalFormat;
import java.util.Scanner;

public class Assessment1A {
	public static void main(String[] args) {
		//declare variables 
		double height,weight,bmiValue,sum,lowBmi,highBmi;
		int highNo,lowNo,normalNo;
		String type;
		//initialize variables
		lowNo=0;
		highNo=0;
		normalNo=0;
		sum=0;
		lowBmi = 0;
		highBmi=0;
		// Create a Scanner object
		Scanner scObj = new Scanner(System.in);
		// Create a BMICalculator object
		BMICalculator bmCal=new BMICalculator();
		
		 DecimalFormat df = new DecimalFormat("0.0");
		
		System.out.println("Welcome to BMI calculator!");
	    System.out.println("How many BMI calculations do you wish to perform? ");
	    int calNo = scObj.nextInt();  // Read user input
	    
		for(int i=1;i<=calNo;i++) {
			System.out.println("Height for person "+i+" (m):");
			height=scObj.nextDouble();
			System.out.println("Weight for person "+i+" (kgs):");
			weight=scObj.nextDouble();
			bmiValue=bmCal.value(weight, height);
			if(i==1) {
				lowBmi=bmiValue;
				highBmi=bmiValue;
			}
			if(lowBmi>bmiValue) {
				lowBmi=bmiValue;
			}
			if(highBmi<bmiValue) {
				highBmi=bmiValue;
			}
			type=bmCal.classification3(bmiValue);
			if(type.equals("Low")) {
				lowNo++;
				
			}else if(type.equals("Normal")) {
				normalNo++;
				
			}else if(type.equals("High")) {
				highNo++;
			}
			sum=sum+bmiValue;
			System.out.println("BMI for person "+i+" : "+df.format(bmiValue)+" which is "+bmCal.classification8(bmiValue));
	
		}
		System.out.println("\n");
		System.out.println("Summary");
		System.out.println("*******");
		System.out.println("Lowest BMI: "+df.format(lowBmi));
		System.out.println("Highest BMI: "+df.format(highBmi));
		System.out.println("Average BMI: "+df.format(sum/calNo));
		System.out.println("Number with low BMI :"+lowNo);
		System.out.println("Number with normal BMI :"+normalNo);
		System.out.println("Number with high BMI :"+highNo);
		System.out.println("Exit from the BMI Calculator.");
		

	}

}
