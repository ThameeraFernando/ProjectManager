module BMICalculator {
}